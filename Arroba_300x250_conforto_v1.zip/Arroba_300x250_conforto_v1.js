(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.webFontTxtInst = {}; 
var loadedTypekitCount = 0;
var loadedGoogleCount = 0;
var gFontsUpdateCacheList = [];
var tFontsUpdateCacheList = [];
lib.ssMetadata = [];



lib.updateListCache = function (cacheList) {		
	for(var i = 0; i < cacheList.length; i++) {		
		if(cacheList[i].cacheCanvas)		
			cacheList[i].updateCache();		
	}		
};		

lib.addElementsToCache = function (textInst, cacheList) {		
	var cur = textInst;		
	while(cur != exportRoot) {		
		if(cacheList.indexOf(cur) != -1)		
			break;		
		cur = cur.parent;		
	}		
	if(cur != exportRoot) {		
		var cur2 = textInst;		
		var index = cacheList.indexOf(cur);		
		while(cur2 != cur) {		
			cacheList.splice(index, 0, cur2);		
			cur2 = cur2.parent;		
			index++;		
		}		
	}		
	else {		
		cur = textInst;		
		while(cur != exportRoot) {		
			cacheList.push(cur);		
			cur = cur.parent;		
		}		
	}		
};		

lib.gfontAvailable = function(family, totalGoogleCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], gFontsUpdateCacheList);		

	loadedGoogleCount++;		
	if(loadedGoogleCount == totalGoogleCount) {		
		lib.updateListCache(gFontsUpdateCacheList);		
	}		
};		

lib.tfontAvailable = function(family, totalTypekitCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], tFontsUpdateCacheList);		

	loadedTypekitCount++;		
	if(loadedTypekitCount == totalTypekitCount) {		
		lib.updateListCache(tFontsUpdateCacheList);		
	}		
};
// symbols:



(lib.imagem1 = function() {
	this.initialize(img.imagem1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,225);


(lib.imagem2 = function() {
	this.initialize(img.imagem2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,225);


(lib.logo1 = function() {
	this.initialize(img.logo1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,143,44);


(lib.logo2 = function() {
	this.initialize(img.logo2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,45,29);


(lib.texto3C = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#22526A").s().p("AgTAYQgJgJAAgOIAAgBQAAgKADgGQAEgIAHgEQAHgDAIAAQANAAAIAHQAHAJAAAPIAAAGIglAAQABAGADADQAEACAEAAQAJAAAGgGIAJALQgEAEgHADQgGAEgIAAQgNAAgJgJgAgIgFIASAAIAAgCQAAgFgCgCQgDgCgEgBQgIAAgBAMg");
	this.shape.setTransform(46.8,4.9,0.856,0.856);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#22526A").s().p("AgVAkQgHgIAAgQQAAgOAHgIQAHgJAKAAQAIAAAGAHIAAggIATAAIAABXIgRAAIgBgGQgHAIgIAAQgKAAgHgJgAgJAJIAAAEQAAARAKAAQAFAAAEgFIAAgZQgDgEgGAAQgIAAgCANg");
	this.shape_1.setTransform(41,3.9,0.856,0.856);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#22526A").s().p("AgSAgIAAg+IASAAIAAAIQAEgJAKAAIAFABIgBASIgGAAQgKAAgCAFIAAAng");
	this.shape_2.setTransform(33.8,4.9,0.856,0.856);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#22526A").s().p("AgIAsIAAg9IASAAIAAA9gAgHgaQgDgEAAgDQAAgEADgEQADgCAEAAQAGAAACACQADAEAAAEQAAADgDAEQgDACgFAAQgDAAgEgCg");
	this.shape_3.setTransform(30.1,3.8,0.856,0.856);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#22526A").s().p("AgGAjQgEgFgBgKIAAgeIgHAAIAAgNIAHAAIAAgQIATAAIAAAQIALAAIAAANIgLAAIAAAcQAAABAAABQAAABAAAAQABABAAAAQAAABABAAQABABADAAIAGAAIAAAOQgFACgGAAQgKAAgFgFg");
	this.shape_4.setTransform(26.9,4.3,0.856,0.856);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#22526A").s().p("AgSAgIAAg+IASAAIAAAIQAGgJAIAAIAFABIAAASIgGAAQgJAAgEAFIAAAng");
	this.shape_5.setTransform(23.1,4.9,0.856,0.856);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#22526A").s().p("AgWAbQgGgFAAgIQAAgKAIgFQAHgFAOAAIAGAAIAAgDQAAgJgHAAQgHAAAAAHIgTAAQAAgJAHgGQAJgGAKABQAMAAAHAFQAHAGAAALIAAAaQAAAHADAHIAAAAIgUAAIgBgGQgGAIgJAAQgIgBgHgFgAgIANQAAAAAAABQAAABAAAAQABABAAAAQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAQAAAAABAAQADABACgCIAEgDIAAgKIgGAAQgJAAAAAJg");
	this.shape_6.setTransform(18.2,4.9,0.856,0.856);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#22526A").s().p("AgcAsIAAhWIATAAIAAAGQAGgHAHAAQANAAAFAJQAHAIAAAPIAAABQAAAOgHAIQgGAJgMAAQgGAAgGgGIAAAdgAgIgXIAAAYQADAFAFAAQAKAAAAgPIAAgCQAAgRgKAAQgGAAgCAFg");
	this.shape_7.setTransform(12.6,5.9,0.856,0.856);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#22526A").s().p("AATAqIgFgPIgbAAIgFAPIgWAAIAfhTIASAAIAgBTgAgIALIARAAIgJgcg");
	this.shape_8.setTransform(3.5,4,0.856,0.856);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,49.4,9.7);


(lib.texto3B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAIQgDgDAAgFQAAgEADgDQADgDAFAAQAFAAADADQAEAEAAADQAAAEgEAEQgDADgFAAQgFAAgDgDg");
	this.shape.setTransform(105.7,10.1,1.139,1.139);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPAhQgHgEgEgFQgEgFAAgGIAVAAQAAAFADACQACACAFAAQAFAAACgCIACgFQAAgCgDgCIgKgEQgIgBgGgDQgEgDgEgDQgCgEAAgGQAAgKAHgGQAIgGAMAAQAOAAAIAGQAJAGAAALIgWAAQAAgJgJAAQgDAAgCACQAAABgBAAQAAABAAAAQgBABAAAAQAAABAAABQAAACADADIATAFQAQAFAAAOQAAAJgJAGQgIAGgOAAQgIAAgHgDg");
	this.shape_1.setTransform(99.4,7.3,1.139,1.139);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAKAkIAAgrQAAgFgDgDQgBgCgGAAQgFAAgEAEIAAAxIgVAAIAAhFIAUAAIABAIQAHgJALAAQALAAAGAGQAFAHABANIAAAsg");
	this.shape_2.setTransform(91.2,7.2,1.139,1.139);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgWAbQgKgKAAgPIAAgCQABgKADgIQAFgJAHgEQAIgEAJAAQAPAAAIAJQAJAKgBAPIAAAIIgpAAQAAAFAEAEQAFAEAEAAQALAAAGgIIAJAMQgDAGgIADQgHADgJAAQgPAAgKgJgAgJgGIAUAAIAAgBQAAgGgCgCQgCgDgGAAQgJAAgBAMg");
	this.shape_3.setTransform(82.8,7.3,1.139,1.139);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgQAvQgHgDgEgFIAJgNQAFAHALAAQAOAAAAgOIAAgDQgIAHgIAAQgMAAgIgJQgIgKAAgQIAAAAQAAgMADgHQAFgJAFgEQAIgEAHAAQALAAAFAHIABgGIAUAAIAABCQAAAKgEAGQgEAHgJAEQgHADgLAAQgGAAgIgCgAgHgaQgDAFAAAKQAAAJADAEQADAFAFAAQAHAAAEgFIAAgdQgEgEgGAAQgGAAgDAFg");
	this.shape_4.setTransform(74,8.8,1.139,1.139);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgYAeQgHgGAAgJQAAgLAJgFQAIgGAPAAIAGAAIAAgDQABgKgIAAQgIAAABAIIgXAAQAAgLAJgGQAKgGALAAQAMAAAKAGQAGAHACALIAAAeQgBAJADAGIAAABIgVAAIgDgGQgGAHgJAAQgKAAgHgGgAgJAOQAAABAAABQAAAAABABQAAAAAAABQAAAAABABQABACAEAAQAEAAACgCIADgEIAAgLIgGAAQgKAAAAAKg");
	this.shape_5.setTransform(65.7,7.3,1.139,1.139);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQAvQgIgEgEgEIAJgNQAHAHAJAAQAOAAAAgOIAAgDQgGAHgJAAQgNAAgHgJQgIgLAAgPIAAAAQAAgMADgHQAEgIAGgFQAGgEAJAAQALAAAFAHIABgGIAUAAIAABCQAAAKgEAGQgEAGgJAFQgHADgLAAQgGAAgIgCgAgHgaQgEAFAAAKQAAAJAEAEQADAFAFAAQAHAAADgFIAAgdQgDgEgHAAQgFAAgDAFg");
	this.shape_6.setTransform(57.1,8.8,1.139,1.139);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgYAeQgHgGAAgJQAAgLAIgFQAJgGAPAAIAGAAIAAgDQABgKgIAAQgIAAAAAIIgWAAQAAgLAJgGQAKgGALAAQANAAAIAGQAIAHAAALIAAAeQAAAKADAFIAAABIgVAAIgDgGQgGAHgJAAQgKAAgHgGgAgKAOQAAABABABQAAAAAAABQAAAAABABQAAAAABABQACACACAAQADAAAEgCIADgEIAAgLIgGAAQgLAAAAAKg");
	this.shape_7.setTransform(48.8,7.3,1.139,1.139);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLAqIgBAHIgTAAIAAhiIAVAAIAAAjQAGgHAJAAQANAAAHAJQAHAKAAAQIAAABQAAAQgHAKQgGAJgOAAQgKAAgGgIgAgKAAIAAAcQADAGAHAAQAIAAABgIQACgDAAgKQAAgKgDgDQgDgEgFAAQgHAAgDAEg");
	this.shape_8.setTransform(40.5,5.7,1.139,1.139);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgPAhQgGgDgFgGQgDgFAAgGIATAAQABAFADACQACACAEAAQAGAAABgCQACgCAAgDQAAgCgDgCIgJgEQgIgBgGgDQgFgDgDgDQgCgFgBgFQABgKAHgGQAIgGAMAAQAOAAAJAGQAHAGABALIgWAAQAAgJgJAAQgCAAgCACQgDACAAADQAAADADACIATAFQAQAEAAAPQAAAKgJAFQgIAGgOAAQgHAAgIgDg");
	this.shape_9.setTransform(28.2,7.3,1.139,1.139);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgYAeQgHgGAAgJQAAgLAJgFQAIgGAPAAIAHAAIAAgDQgBgKgHAAQgIAAAAAIIgVAAQgBgLAKgGQAIgGAMAAQANAAAJAGQAGAHABALIAAAeQAAAJADAGIAAABIgWAAIgCgGQgFAHgLAAQgJAAgHgGgAgJAOQAAABAAABQAAAAABABQAAAAAAABQABAAAAABQACACADAAQADAAADgCIAEgEIAAgLIgHAAQgKAAAAAKg");
	this.shape_10.setTransform(20.2,7.3,1.139,1.139);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgYAdQgHgGAAgOIAAgsIAWAAIAAAtQAAAJAJAAQAGAAAEgFIAAgxIAVAAIAABFIgUAAIAAgIQgHAJgLAAQgMABgFgHg");
	this.shape_11.setTransform(11.9,7.4,1.139,1.139);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgPAhQgHgEgEgFQgEgFAAgGIAVAAQAAAFADACQACACAFAAQAEAAACgCQADgCAAgDQAAgCgDgCIgKgEQgIgBgGgDQgEgDgEgDQgCgEAAgGQAAgKAHgGQAIgGAMAAQAOAAAIAGQAJAGAAALIgWAAQAAgJgJAAQgDAAgCACQAAABgBAAQAAABAAAAQgBABAAAAQAAABAAABQAAACADADIAIADIALACQAQAFAAAOQAAAJgJAGQgIAGgOAAQgIAAgHgDg");
	this.shape_12.setTransform(3.5,7.3,1.139,1.139);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,107.1,14.4);


(lib.texto3A = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVAfQgGgGAAgJQAAgKAJgGQAIgFAOAAIAOAAIAAgHQAAgIgEgEQgFgFgJAAQgHAAgFAFQgGADAAAHIgIgBQAAgHAIgHQAIgGAKAAQAMAAAHAGQAGAFABALIAAAgQAAALACAEIAAABIgJAAIgBgKQgEAGgGACQgGADgHAAQgJAAgHgFgAgMAFQgHADAAAIQAAAGAEAEQAEADAIAAQAGAAAGgDQAGgEADgGIAAgQIgNAAQgLAAgGAFg");
	this.shape.setTransform(165.4,7.3,1.139,1.139);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPAjIAAhEIAHAAIAAALQAHgNAMAAIAFABIAAAHIgFAAQgHAAgEAEQgGAFgCAHIAAAug");
	this.shape_1.setTransform(159.6,7.2,1.139,1.139);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAfQgGgGAAgJQAAgKAJgGQAIgFAOAAIAOAAIAAgHQAAgIgEgEQgFgFgJAAQgHAAgFAFQgGAEAAAGIgHgBQAAgIAHgGQAIgGAKAAQAMAAAHAGQAHAGAAAKIAAAgQAAAIACAHIAAABIgIAAQgCgDAAgHQgFAHgFABQgGADgGAAQgKAAgHgFgAgNAFQgGADAAAIQAAAGAEAEQAEADAHAAQAIAAAFgDQAGgEADgGIAAgQIgOAAQgKAAgHAFg");
	this.shape_2.setTransform(152.3,7.3,1.139,1.139);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbAxIAAhfIAHAAIAAAKQAIgMANAAQAMAAAIAKQAHAJAAARIAAABQAAAPgHAKQgHAKgMAAQgOgBgIgJIAAAjgAgMglQgEACgEAHIAAAhQAEAGAEADQAGADAGAAQAJAAAGgIQAFgHAAgOQAAgOgGgIQgEgHgKAAQgHAAgFAEg");
	this.shape_3.setTransform(144.7,8.8,1.139,1.139);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgaAvIAAhdIAIAAIAABWIAtAAIAAAHg");
	this.shape_4.setTransform(132.4,6,1.139,1.139);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgTAmQgJgJAAgQIAAgIQAAgYAMgOQALgNAUgBIACAAIAAAHIgBAAQgQAAgJAKQgKAKgBARQADgFAHgDQAFgDAHAAQANAAAGAIQAIAJAAANQAAAKgDAGQgDAHgHAFQgHAEgIAAQgNAAgHgKgAgMgDQgGAEgCAGIAAAHQgBAMAHAIQAGAHAJAAQAJAAAGgGQAGgJgBgJQABgMgGgFQgGgHgKAAQgFAAgHAEg");
	this.shape_5.setTransform(123.8,6,1.139,1.139);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgOAtQgHgDgEgGQgDgHAAgHIAIAAQAAAIAFAGQAIAGAIAAQAKAAAGgFQAFgGAAgJQAAgJgGgGQgGgFgLAAIgHAAIAAgFIAIAAQAFAAAFgCQAGgDACgEQACgDAAgGQAAgKgFgFQgGgFgJAAQgHAAgHAGQgFAFAAAJIgIAAQAAgHAEgHQAEgGAGgDQAGgDAHAAQANAAAHAHQAIAHAAAMQAAAHgEAFQgEAFgIAEQAJACAEAFQAFAGgBAJQAAAMgHAHQgIAHgNAAQgIAAgHgDg");
	this.shape_6.setTransform(115,6,1.139,1.139);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgSApQgIgIgBgLIAHAAQABAKAFAEQAGAFAIAAQAKAAAGgHQAEgFAAgNQABgKgGgGQgGgGgJAAQgFAAgEACQgFACgEACIgGgBIAFguIAtAAIAAAIIgnAAIgDAfQAIgFAIAAQANAAAIAJQAHAHAAANQAAAPgHAJQgIAHgNABQgMgBgGgGg");
	this.shape_7.setTransform(107,6,1.139,1.139);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgMAgQgHgEgFgIQgEgJAAgJIAAgCQAAgJAEgJQAEgHAHgFQAHgFAHAAQAOAAAGAJQAIAIAAAPIAAAEIgxAAIAAABQAAANAHAHQAGAIAKAAQAHAAAEgCQAFgCAEgGIAEAEQgIAMgQAAQgIAAgHgEgAgMgWQgGAHgCAKIApAAIAAgBQAAgJgFgHQgGgGgJAAQgHAAgGAGg");
	this.shape_8.setTransform(94.7,7.3,1.139,1.139);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgUApQgHgKAAgRIAAgBQAAgPAHgJQAHgKANAAQANAAAHALIAAgnIAIAAIAABiIgHAAIAAgJQgIAKgNAAQgMAAgIgJgAgOgHQgFAHAAAPQAAAOAFAHQAFAIAJAAQAOAAAGgNIAAggQgGgNgOAAQgIAAgGAHg");
	this.shape_9.setTransform(86.3,5.7,1.139,1.139);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgNAgQgHgFgEgHQgEgJAAgJIAAgCQAAgJAEgJQAEgIAHgEQAHgFAHAAQANAAAHAJQAIAIAAAPIAAAEIgxAAIAAABQAAAMAHAIQAGAIAKAAQAHAAAEgCQAFgDADgFIAFAEQgIAMgQAAQgIAAgIgEgAgNgWQgFAGgCALIApAAIAAgBQAAgJgGgHQgFgGgJAAQgIAAgGAGg");
	this.shape_10.setTransform(74.5,7.3,1.139,1.139);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgUApQgHgKAAgRIAAgBQAAgPAHgJQAHgKANAAQANAAAIALIAAgnIAHAAIAABiIgHAAIAAgJQgIAKgNAAQgMAAgIgJgAgOgHQgFAHAAAPQAAAOAFAHQAFAIAJAAQAOAAAHgNIAAggQgHgNgNAAQgJAAgGAHg");
	this.shape_11.setTransform(66,5.7,1.139,1.139);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAfQgGgGAAgJQAAgKAJgGQAIgFAOAAIAOAAIAAgHQAAgIgEgEQgFgFgJAAQgHAAgFAFQgGADABAHIgJgBQAAgIAJgGQAHgGAKAAQAMAAAGAGQAIAGAAAKIAAAgQgBAJADAGIAAABIgJAAIgBgKQgEAGgGACQgHADgGAAQgJAAgHgFgAgNAFQgGAEAAAHQgBAGAFAEQAEADAIAAQAGAAAGgDQAGgEADgGIAAgQIgOAAQgKAAgHAFg");
	this.shape_12.setTransform(57.7,7.3,1.139,1.139);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgUApQgHgKAAgRIAAgBQAAgPAHgJQAIgKAMAAQANAAAHALIAAgnIAIAAIAABiIgHAAIAAgJQgIAKgNAAQgMAAgIgJgAgOgHQgFAHAAAPQAAANAFAIQAFAIAJAAQAOAAAGgNIAAggQgGgNgOAAQgIAAgGAHg");
	this.shape_13.setTransform(49.3,5.7,1.139,1.139);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgDAvIAAhEIAHAAIAABEgAgDgmQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAABABQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBg");
	this.shape_14.setTransform(43.5,5.9,1.139,1.139);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgTAbQgIgKAAgQIAAgBQAAgLADgHQAEgIAHgFQAHgEAHAAQALAAAIAHQAIAHAAALIgHAAQAAgJgGgEQgFgFgJAAQgJAAgGAHQgGAIAAANIAAABQAAAOAGAHQAGAIAKAAQAHAAAGgFQAGgEAAgIIAHAAQAAAHgEAFQgDAFgGADQgGADgHAAQgNAAgIgJg");
	this.shape_15.setTransform(37.8,7.3,1.139,1.139);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgVAfQgGgGAAgJQAAgKAJgGQAIgFAOAAIAOAAIAAgHQAAgIgEgEQgFgFgJAAQgHAAgFAFQgGAEAAAGIgHgBQAAgIAHgGQAIgGAKAAQAMAAAHAGQAHAGAAAKIAAAgQAAAIACAHIAAABIgIAAQgCgDAAgHQgEAGgGACQgGADgGAAQgKAAgHgFgAgNAFQgGADAAAIQAAAGAEAEQAEADAHAAQAIAAAFgDQAGgEADgGIAAgQIgOAAQgKAAgHAFg");
	this.shape_16.setTransform(29.6,7.3,1.139,1.139);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgbAxIAAhfIAHAAIAAAKQAIgMANAAQAMAAAIAKQAHAJAAARIAAABQAAAPgHAKQgHAKgMAAQgOgBgIgJIAAAjgAgMglQgEACgEAHIAAAhQAEAGAEADQAGADAGAAQAJAAAGgIQAFgIAAgNQAAgNgFgJQgGgHgJAAQgHAAgFAEg");
	this.shape_17.setTransform(21.5,8.8,1.139,1.139);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgUAfQgHgHAAgIQAAgKAIgGQAKgFAOAAIANAAIAAgHQAAgIgEgEQgFgFgJAAQgGAAgGAFQgFAEgBAGIgHgBQAAgIAHgGQAJgGAJAAQAMAAAHAGQAHAGAAAKIAAAgQAAALACAEIAAABIgIAAQgCgDAAgHQgFAGgFACQgGADgGAAQgKAAgGgFgAgMAFQgHADAAAIQAAAGAFAEQADADAIAAQAHAAAFgDQAHgEACgGIAAgQIgNAAQgLAAgGAFg");
	this.shape_18.setTransform(12.8,7.3,1.139,1.139);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgRArQgIgFgFgKQgEgJAAgNIAAgLQAAgMAEgKQAGgKAHgFQAIgFAKAAQAOAAAKAIQAJAIABAOIgIAAQgDgXgXAAQgMAAgIAJQgHAJAAARIAAALQAAAQAHAKQAIAKAMAAQAMAAAGgGQAHgGABgMIAIAAQgBAPgKAHQgIAIgPAAQgKAAgIgFg");
	this.shape_19.setTransform(4,6,1.139,1.139);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,168.6,14.4);


(lib.texto2B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#22526A").s().p("AgFAFQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAgBIABgEQADgCACAAQADAAACACIACAEQAAABAAAAQAAABgBABQAAAAAAABQAAAAgBABQgBACgEAAQgDAAgCgCg");
	this.shape.setTransform(189.1,6.5,0.73,0.73);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#22526A").s().p("AgVAYQgIgIAAgQIAAAAQAAgKAEgHQAEgIAGgEQAHgEAIAAQANAAAIAKQAJAJAAAOIAAABQAAAJgEAIQgDAHgHAFQgIAEgIAAQgNAAgIgKgAgNgRQgFAHAAALQAAAKAFAHQAGAHAHAAQAJAAAEgHQAFgHAAgLQAAgLgFgGQgFgHgIABQgIgBgFAHg");
	this.shape_1.setTransform(185.2,4.5,0.73,0.73);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#22526A").s().p("AgUApQgGgFAAgJQAAgKAIgGQAIgFANgBIAKAAIAAgFQABgEgEgEQgFgDgFgBQgGAAgDADQgFADAAAFIgLAAQAAgEADgGQAFgFAFgCQAGgDAGAAQAMAAAGAHQAHAFgBAJIAAAeQAAAIADAGIAAABIgMAAIgCgGQgHAHgKABQgKAAgGgGgAgPAZQAAAGADADQAFACAEAAQAGAAADgCQAGgEABgDIAAgNIgJAAQgTgBAAAMgAgTgeQAAgFAEgFQADgFAGAAIAEABIAIAFIAEAAQAAAAABAAQAAAAAAAAQABAAAAgBQABAAAAAAQACgDAAgDIAIABQAAAGgEAFQgEAEgFAAIgFAAIgIgGIgDAAQAAAAAAAAQgBAAAAABQgBAAAAAAQgBABAAAAQgDACAAADg");
	this.shape_2.setTransform(180.1,3.6,0.73,0.73);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#22526A").s().p("AgMAfQgGgCgDgFQgEgFAAgGIALAAQABAFADAEQAGADAEAAQAHAAAEgCQADgDABgFQAAgEgDgDQgEgDgIgBQgIgCgFgCQgFgBgCgEQgDgEAAgEQAAgIAHgHQAHgFAJAAQALAAAHAGQAIAFgBAKIgLAAQAAgFgEgDQgDgDgHAAQgGAAgDACQgCADAAAEQAAAEACACQACACAJACQAJABAEADQAFACAEAEQACAEAAAFQAAAIgHAFQgIAGgLAAQgGAAgGgDg");
	this.shape_3.setTransform(175.2,4.5,0.73,0.73);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#22526A").s().p("AgPAhIAAhAIALAAIAAAIQAFgJAKAAIAFABIAAAKIgGAAQgKAAgEAJIAAAtg");
	this.shape_4.setTransform(171.5,4.5,0.73,0.73);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#22526A").s().p("AgSAZQgJgJAAgOIAAgCQAAgIAEgJQAEgHAGgFQAIgEAGAAQAMAAAIAIQAHAJAAAPIAAAEIgrAAQAAAJAFAHQAFAGAIAAQAFAAAFgCQADgCAEgFIAHAGQgIAMgRAAQgMAAgIgJgAgJgTQgGAFAAAJIAgAAIAAgBQgCgJgDgEQgFgFgGABQgGgBgEAFg");
	this.shape_5.setTransform(167.3,4.5,0.73,0.73);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#22526A").s().p("AgDAhIgYhAIAMAAIAPAwIAQgwIAMAAIgYBAg");
	this.shape_6.setTransform(162.6,4.5,0.73,0.73);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#22526A").s().p("AgUAcQgGgFAAgIQAAgKAIgGQAIgFANAAIALAAIAAgFQAAgFgEgEQgEgEgGAAQgFAAgEADQgEADAAAFIgMAAQAAgGAEgEQAEgFAFgCQAGgDAGAAQAMAAAGAGQAHAFAAALIAAAcQAAAKACAFIAAABIgMAAIgBgHQgIAIgKAAQgJAAgHgGgAgPANQAAAFAEAEQAEACAFAAQAFAAAEgCQAFgEACgDIAAgOIgJAAQgUAAAAAMg");
	this.shape_7.setTransform(155.6,4.5,0.73,0.73);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#22526A").s().p("AgTAlQgIgIABgQIAAgBQgBgOAIgIQAGgKAMAAQALAAAHAIIAAgiIALAAIAABcIgLAAIAAgIQgIAJgKAAQgLAAgHgKgAgLgEQgEAFgBANQABALAEAGQAEAGAIAAQAKAAAGgJIAAgdQgGgKgKABQgIgBgEAHg");
	this.shape_8.setTransform(150.4,3.6,0.73,0.73);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#22526A").s().p("AgUAcQgGgEAAgJQAAgKAIgGQAIgFAMAAIALAAIAAgFQABgGgEgDQgFgEgFAAQgFAAgEADQgFADAAAFIgLAAQABgGADgEQADgEAGgDQAGgDAHAAQALAAAGAGQAHAFAAALIAAAcQAAAKACAFIAAABIgLAAIgDgHQgHAIgKAAQgJAAgHgGgAgPANQAAAFADAEQAFACAEAAQAGAAAEgCQAEgEACgDIAAgOIgIAAQgUAAAAAMg");
	this.shape_9.setTransform(145.4,4.5,0.73,0.73);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#22526A").s().p("AgSAZQgJgIABgRIAAAAQAAgLADgGQAEgIAGgEQAHgEAHAAQALAAAIAGQAHAIABAKIgLAAQgBgHgEgEQgDgDgIAAQgHAAgEAFQgGAGAAAMIAAABQAAAMAGAFQAEAHAHAAQAGAAAFgEQAEgDABgGIALAAQgBAGgDAFQgEAFgGADQgGADgHAAQgMAAgHgJg");
	this.shape_10.setTransform(140.5,4.5,0.73,0.73);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#22526A").s().p("AgUAcQgGgEAAgJQAAgKAIgGQAIgFAMAAIALAAIAAgFQABgGgEgDQgFgEgFAAQgFAAgEADQgFADAAAFIgLAAQABgGADgEQADgFAGgCQAGgDAHAAQALAAAGAGQAHAFAAALIAAAcQAAAJACAGIAAABIgMAAIgCgHQgHAIgKAAQgJAAgHgGgAgPANQAAAFADAEQAFACAEAAQAGAAAEgCQAEgEACgDIAAgOIgJAAQgTAAAAAMg");
	this.shape_11.setTransform(133.2,4.5,0.73,0.73);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#22526A").s().p("AgMAfQgEgCgGgFQgDgFAAgGIALAAQABAFAEAEQAFADAFAAQAGAAAEgCQAEgDAAgFQAAgEgEgDQgEgDgHgBQgIgCgFgCQgFgBgDgEQgCgDAAgFQABgIAGgHQAHgFAKAAQALAAAHAGQAGAFABAKIgMAAQAAgFgEgDQgDgDgGAAQgGAAgDACQgEACAAAFQABAEADACIAKAEQAJABAFADQAGACABAEQADACAAAHQAAAJgHAEQgHAGgLAAQgHAAgGgDg");
	this.shape_12.setTransform(126,4.5,0.73,0.73);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#22526A").s().p("AgSAZQgJgJAAgOIAAgCQAAgIAEgJQAEgHAHgFQAGgEAHAAQANAAAHAIQAHAIAAAQIAAAEIgrAAQAAAJAFAHQAGAGAHAAQAFAAAFgCQAEgCADgFIAHAGQgIAMgRAAQgMAAgIgJgAgJgTQgFAFgBAJIAgAAIAAgBQgBgJgEgEQgEgFgHABQgGgBgEAFg");
	this.shape_13.setTransform(121.2,4.5,0.73,0.73);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#22526A").s().p("AgBAlQgEgEAAgJIAAgoIgMAAIAAgIIAMAAIAAgQIAKAAIAAAQIAMAAIAAAIIgMAAIAAAoQAAAEACACQABACAEAAIAGgBIAAAJIgJABQgHAAgDgEg");
	this.shape_14.setTransform(117.1,4,0.73,0.73);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#22526A").s().p("AAPAhIAAgqQAAgHgEgDQgDgEgGAAQgFAAgEADQgEADgCAFIAAAtIgMAAIAAhAIALAAIAAAIQAIgJALAAQAVAAAAAXIAAAqg");
	this.shape_15.setTransform(113.2,4.5,0.73,0.73);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#22526A").s().p("AgSAZQgJgJAAgOIAAgCQAAgJAEgIQAEgHAGgFQAHgEAHAAQAMAAAIAIQAHAJAAAPIAAAEIgsAAQABALAFAFQAGAGAHAAQAGAAAEgCQAEgCADgFIAHAGQgJAMgQAAQgMAAgIgJgAgKgTQgEAEgBAKIAgAAIAAgBQgBgJgEgEQgEgFgHABQgFgBgGAFg");
	this.shape_16.setTransform(108.2,4.5,0.73,0.73);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#22526A").s().p("AgPAhIAAhAIALAAIAAAIQAFgJAKAAIAFABIAAAKIgGAAQgKAAgEAJIAAAtg");
	this.shape_17.setTransform(104.5,4.5,0.73,0.73);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#22526A").s().p("AgSAZQgJgJAAgOIAAgCQAAgIAEgJQAEgHAHgFQAGgEAHAAQANAAAHAIQAHAIAAAQIAAAEIgrAAQAAAJAFAHQAGAGAHAAQAFAAAFgCQAEgCADgFIAHAGQgIAMgRAAQgMAAgIgJgAgJgTQgFAFgBAJIAgAAIAAgBQgBgJgEgEQgEgFgHABQgGgBgEAFg");
	this.shape_18.setTransform(100.3,4.5,0.73,0.73);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#22526A").s().p("AgJAvIAAg4IgKAAIAAgIIAKAAIAAgHQAAgKAGgGQAFgGAKAAIAIABIgBAJIgGgBQgFABgDADQgDADAAAGIAAAHIAOAAIAAAIIgOAAIAAA4g");
	this.shape_19.setTransform(96.5,3.5,0.73,0.73);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#22526A").s().p("AgSAZQgJgJAAgOIAAgCQAAgJAEgIQAEgHAGgFQAHgEAHAAQAMAAAIAIQAHAJAAAPIAAAEIgsAAQABALAFAFQAGAGAHAAQAGAAAEgCQAEgCADgFIAHAGQgJAMgQAAQgMAAgIgJgAgKgTQgEAEgBAKIAgAAIAAgBQgBgJgEgEQgEgFgHABQgFgBgGAFg");
	this.shape_20.setTransform(92.3,4.5,0.73,0.73);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#22526A").s().p("AgPAhIAAhAIALAAIAAAIQAFgJAKAAIAFABIAAAKIgGAAQgKAAgEAJIAAAtg");
	this.shape_21.setTransform(88.6,4.5,0.73,0.73);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#22526A").s().p("AgMAfQgFgCgEgFQgEgHAAgEIAMAAQgBAFAFAEQAFADAFAAQAGAAAEgCQAEgDAAgFQAAgEgDgDQgFgDgHgBQgHgCgGgCQgFgBgDgEQgBgDAAgFQAAgIAGgHQAHgFAJAAQAMAAAGAGQAIAFgBAKIgLAAQAAgFgDgDQgEgDgHAAQgFAAgDACQgDACAAAFQAAAEACACIAMAEQAIABAFADQAFACACAEQADACAAAHQAAAJgHAEQgHAGgLAAQgHAAgGgDg");
	this.shape_22.setTransform(82,4.5,0.73,0.73);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#22526A").s().p("AgSAZQgJgJAAgOIAAgCQAAgIAEgJQAEgHAHgFQAGgEAHAAQANAAAHAIQAHAIAAAQIAAAEIgrAAQAAAJAFAHQAGAGAHAAQAFAAAFgCQAEgCADgFIAHAGQgIAMgRAAQgMAAgIgJgAgJgTQgFAFgBAJIAgAAIAAgBQgBgJgEgEQgEgFgHABQgGgBgEAFg");
	this.shape_23.setTransform(77.3,4.5,0.73,0.73);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#22526A").s().p("AgPAhIAAhAIALAAIAAAIQAFgJAKAAIAFABIAAAKIgGAAQgKAAgEAJIAAAtg");
	this.shape_24.setTransform(73.5,4.5,0.73,0.73);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#22526A").s().p("AgUAYQgJgJAAgPIAAAAQAAgIAEgJQAEgIAHgEQAHgEAHAAQAOAAAIAKQAIAIAAAPIAAABQAAAKgEAHQgEAIgGAEQgHAEgJAAQgMAAgIgKgAgMgRQgFAGAAAMQAAALAFAGQAFAHAHAAQAIAAAGgHQAFgHAAgLQAAgLgFgGQgFgHgJABQgHgBgFAHg");
	this.shape_25.setTransform(69.1,4.5,0.73,0.73);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#22526A").s().p("AgEAuIAAhbIAJAAIAABbg");
	this.shape_26.setTransform(65.4,3.5,0.73,0.73);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#22526A").s().p("AgUAcQgGgEAAgJQAAgKAIgGQAIgFAMAAIALAAIAAgFQAAgFgDgEQgFgEgFAAQgGAAgDADQgFADAAAFIgLAAQAAgEADgGQAFgFAFgCQAGgDAGAAQAMAAAGAGQAHAFAAALIAAAcQAAAJACAGIAAABIgMAAIgCgHQgHAIgKAAQgJAAgHgGgAgPANQAAAFAEAEQADACAGAAQAFAAAEgCQAFgEABgDIAAgOIgJAAQgTAAAAAMg");
	this.shape_27.setTransform(61.7,4.5,0.73,0.73);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#22526A").s().p("AgDAhIgYhAIAMAAIAPAwIAQgwIAMAAIgYBAg");
	this.shape_28.setTransform(57,4.5,0.73,0.73);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#22526A").s().p("AgMAfQgFgCgFgFQgDgHAAgEIALAAQABAFAEAEQAEADAGAAQAGAAAEgCQAEgDAAgFQAAgEgDgDQgEgDgIgBQgIgCgFgCQgFgCgCgDQgCgDgBgFQABgIAGgHQAHgFAKAAQALAAAHAGQAGAFABAKIgMAAQAAgFgDgDQgEgDgGAAQgGAAgDACQgEACAAAFQAAAEAEACQACACAIACQAJABAFADQAFACACAEQADACAAAHQAAAJgHAEQgHAGgLAAQgHAAgGgDg");
	this.shape_29.setTransform(50.1,4.5,0.73,0.73);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#22526A").s().p("AgUAYQgJgJAAgPIAAAAQAAgIAEgJQAEgIAHgEQAHgEAHAAQAOAAAIAKQAIAIAAAPIAAABQAAAKgEAHQgEAIgGAEQgHAEgJAAQgMAAgIgKgAgMgRQgFAGAAAMQAAALAFAGQAEAHAIAAQAIAAAGgHQAFgIAAgKQAAgKgFgHQgFgHgJABQgIgBgEAHg");
	this.shape_30.setTransform(45.1,4.5,0.73,0.73);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#22526A").s().p("AgTAZQgIgIAAgPIAAgCQAAgJAEgIQAEgHAGgFQAHgEAHAAQAMAAAIAIQAHAJAAAPIAAAEIgsAAQAAAJAGAHQAGAGAHAAQAGAAAEgCQADgCAEgFIAHAGQgJAMgQAAQgMAAgJgJgAgKgTQgFAFAAAJIAfAAIAAgBQAAgJgEgEQgEgFgHABQgGgBgFAFg");
	this.shape_31.setTransform(37.7,4.5,0.73,0.73);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#22526A").s().p("AgBAlQgEgFAAgIIAAgoIgMAAIAAgIIAMAAIAAgQIAKAAIAAAQIANAAIAAAIIgNAAIAAAoQAAAEACACQACACAEAAIAFgBIAAAJIgJABQgHAAgDgEg");
	this.shape_32.setTransform(33.6,4,0.73,0.73);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#22526A").s().p("AgFAuIAAhbIALAAIAABbg");
	this.shape_33.setTransform(31.1,3.5,0.73,0.73);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#22526A").s().p("AgTAbQgGgGAAgMIAAgpIALAAIAAApQAAAPANAAQALAAAFgKIAAguIALAAIAABAIgLAAIAAgGQgGAHgMAAQgLAAgFgGg");
	this.shape_34.setTransform(27.4,4.6,0.73,0.73);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#22526A").s().p("AgMAfQgGgCgEgFQgDgFAAgGIALAAQABAFAEAEQAFADAFAAQAGAAAEgCQAEgDgBgFQAAgEgCgDQgEgDgIgBQgJgCgEgCQgFgBgDgEQgCgEAAgEQAAgIAHgHQAHgFAKAAQALAAAHAGQAGAFABAKIgMAAQAAgFgEgDQgEgDgFAAQgHAAgCACQgEACAAAFQAAAEAEACQACACAIACQAJABAEADQAGACACAEQADAEAAAFQAAAIgHAFQgIAGgKAAQgHAAgGgDg");
	this.shape_35.setTransform(22.5,4.5,0.73,0.73);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#22526A").s().p("AAPAhIAAgqQAAgHgEgDQgDgEgHAAQgEAAgEADQgFAEgCAEIAAAtIgLAAIAAhAIALAAIAAAIQAIgJALAAQAVAAAAAXIAAAqg");
	this.shape_36.setTransform(17.6,4.5,0.73,0.73);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#22526A").s().p("AgVAYQgIgJAAgPIAAAAQAAgIAEgJQAEgIAHgEQAGgEAIAAQANAAAJAKQAIAJAAAOIAAABQAAAJgEAIQgEAIgHAEQgGAEgJAAQgMAAgJgKgAgMgRQgFAGgBAMQABALAFAGQAFAHAHAAQAIAAAGgHQAEgHAAgLQAAgLgEgGQgFgHgJABQgIgBgEAHg");
	this.shape_37.setTransform(12.4,4.5,0.73,0.73);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#22526A").s().p("AgYAiQgJgLAAgTIAAgHQAAgNAFgJQAEgJAIgFQAHgFAKAAQAPAAAIAIQAJAHABAOIgMAAQgBgKgFgFQgGgFgJAAQgKAAgGAIQgHAJAAAPIAAAHQABAPAFAIQAHAJAJAAQAKAAAGgFQAFgFABgKIAMAAQgDAPgHAHQgKAHgOAAQgOAAgKgLg");
	this.shape_38.setTransform(6.9,3.7,0.73,0.73);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#22526A").s().p("AAAAIIgKARIgIgFIAMgRIgSgEIADgKIASAHIAAgVIAIAAIgBAWIASgHIADAJIgTAFIAMAQIgIAGg");
	this.shape_39.setTransform(1.8,2.3,0.73,0.73);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,189.6,7);


(lib.texto2A = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#22526A").s().p("AAAALIgOAWIgMgJIARgUIgZgGIAFgOIAYAKIgCgbIAQAAIgCAbIAXgJIAFAOIgZAGIARAUIgOAJg");
	this.shape.setTransform(110.4,4.6,0.856,0.856);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#22526A").s().p("AgvBMQgSgVAAgmIAAghQAAgnARgUQASgVAeAAQAgAAARAVQARAVAAAmIAAAhQAAAngRAUQgRAVggAAQgeAAgRgVgAgPg1QgGAKAAASIAAAwQAAAVAFAKQAGAJAKAAQAMAAAEgJQAGgKAAgUIAAguQAAgVgGgJQgFgKgLAAQgLAAgEAJg");
	this.shape_1.setTransform(100.5,10.6,0.856,0.856);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#22526A").s().p("AgwBMQgRgUAAgnIAAghQAAgnARgUQASgVAeAAQAgAAARAVQARAUAAAnIAAAhQAAAngRAUQgRAVggAAQgeAAgSgVgAgPg1QgFAJgBATIAAAwQAAAVAFAKQAFAJALAAQAMAAAFgJQAFgKAAgUIAAguQAAgUgFgKQgGgKgLAAQgLAAgEAJg");
	this.shape_2.setTransform(87,10.6,0.856,0.856);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#22526A").s().p("AgkBhIAAgjIAIAAQAtgCAFgnQgPANgQAAQgaAAgPgRQgPgRAAgdQAAgSAIgPQAJgQAPgJQAPgJASAAQATAAAOAJQAQAKAIARQAIAPABAZIAAAQQAAAfgNAXQgLAXgXAMQgWAMgeAAgAgPg1QgGALAAANQAAAQAGAIQAHAIAKAAQAOAAAGgMIAAgSQAAgSgGgJQgGgIgKAAQgJAAgGAJg");
	this.shape_3.setTransform(73.6,10.6,0.856,0.856);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#22526A").s().p("AgRAQQgGgHAAgJQAAgJAGgGQAIgGAJAAQAKAAAHAGQAHAGAAAJQAAAJgHAHQgHAGgKAAQgJAAgIgGg");
	this.shape_4.setTransform(63.3,17,0.856,0.856);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#22526A").s().p("AgvBMQgSgVAAgmIAAghQAAgmASgVQAQgVAfAAQAgAAAQAVQASAVAAAmIAAAhQAAAngSAUQgQAVggAAQgeAAgRgVgAgQg1QgFAKAAASIAAAwQAAAWAFAJQAGAJAKAAQALAAAGgJQAFgKAAgUIAAguQAAgVgFgJQgGgKgLAAQgKAAgGAJg");
	this.shape_5.setTransform(53.1,10.6,0.856,0.856);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#22526A").s().p("AghBYQgRgKgIgQQgIgRgBgWIAAgSQAAgbANgYQANgYAXgNQAWgNAcAAIAGAAIAAAiIgBAAQgYAAgQAMQgPAMgEAVQAPgPAVAAQAZAAAPASQAOARAAAdQAAASgJAPQgIAQgPAIQgQAIgSAAQgTAAgQgJgAgPAFQgFAEgDAGIAAANQAAAjAYAAQAKAAAHgIQAGgJAAgOQAAgOgGgIQgIgJgKAAQgIAAgHAEg");
	this.shape_6.setTransform(39.9,10.6,0.856,0.856);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#22526A").s().p("AgHB8IAAgaQgcgDgPgRQgQgQAAgbIAtAAQAAAPAGAHQAHAIALAAQAIAAAFgFQAGgGAAgJQAAgKgGgGQgFgGgMgFIgXgKQgLgGgHgGQgIgHgFgJQgDgKAAgNQgBgVAQgPQAOgOAZgCIAAgcIATAAIAAAcQAYAEAOAQQAOAQAAAYIgsAAQAAgLgGgJQgEgHgKAAQgIAAgFAFQgFAFABAKQgBAKAGAFQAFAGALAFIAXAKQALAGAIAGQAHAHAFAJQAEAJABAOQAAAWgPAOQgNAOgZADIAAAag");
	this.shape_7.setTransform(20.5,10.6,0.856,0.856);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#22526A").s().p("AAbBfIgghEIgZAAIAABEIgtAAIAAi8IBKAAQAhAAATAOQATAPAAAcQAAATgIANQgJAMgQAIIAnBMIAAADgAgegHIAdAAQAMABAHgIQAGgGAAgNQAAgMgGgHQgHgGgMgBIgdAAg");
	this.shape_8.setTransform(6.5,10.7,0.856,0.856);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,113.4,21.2);


(lib.texto1B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#22526A").s().p("AgHAHQgDgDAAgEQAAgDADgDQADgDAEAAQAFAAADADQADADAAADQAAAEgDADQgDADgFAAQgEAAgDgDg");
	this.shape.setTransform(253.7,10.7,1.345,1.345);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#22526A").s().p("AgOAeQgGgEgDgEQgDgFAAgGIASAAQAAAFACACQAFACACAAQAEAAACgCQAAAAAAgBQABAAAAgBQAAAAAAgBQABAAAAgBQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAgBgBAAQgCgBgHgCIgMgFQgFgCgCgDQgCgDgBgFQAAgKAIgFQAHgGAKABQAMgBAIAGQAHAGAAAJIgTAAQAAgHgIgBIgEACQAAABgBAAQAAABAAAAQgBABAAAAQAAABAAABQAAAAAAABQAAABABAAQAAAAAAABQABAAAAAAIAHADIAKADQAOAEAAANQAAAHgHAGQgHAGgNAAQgIgBgGgCg");
	this.shape_1.setTransform(247.1,7.7,1.345,1.345);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#22526A").s().p("AAJAgIAAgmQAAgFgCgCQgDgDgEAAQgFAAgDAEIAAAsIgTAAIAAg+IASAAIABAIQAGgJAKAAQAKAAAFAGQAFAHAAALIAAAng");
	this.shape_2.setTransform(238.6,7.7,1.345,1.345);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#22526A").s().p("AgTAYQgKgIABgPIAAgBQAAgJADgHQAEgHAGgFQAIgDAHAAQAOgBAIAJQAHAJAAANIAAAIIgmAAQABAFAEADQAEACAEAAQAKAAAEgGIAJALQgDAEgHADQgGAEgIAAQgOAAgIgJgAgJgFIATAAIAAgCQAAgFgDgCQgCgCgFgBQgHAAgCAMg");
	this.shape_3.setTransform(229.9,7.7,1.345,1.345);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#22526A").s().p("AgPApQgEgBgGgFIAIgMQAHAHAIAAQAMAAAAgOIAAgCQgFAHgIAAQgMAAgGgJQgIgJAAgOIAAgBQAAgKADgGQAEgIAFgEQAGgDAIAAQAIgBAGAHIABgFIASAAIAAA7QAAAIgEAHQgEAGgHADQgJADgHAAQgHAAgHgDgAgGgXQgDAEAAAJQAAAHACAEQADAEAFAAQAGAAADgDIAAgaQgDgEgGgBQgEAAgDAGg");
	this.shape_4.setTransform(220.7,9.4,1.345,1.345);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#22526A").s().p("AgWAbQgGgEAAgJQAAgKAHgFQAJgFAMAAIAGAAIAAgDQAAgJgGAAQgHAAAAAHIgUAAQAAgJAIgGQAIgGALABQANAAAGAFQAHAHAAAJIAAAbQAAAJADAFIAAABIgUAAIgCgGQgFAGgIABQgJAAgHgGgAgJANQAAABABAAQAAABAAAAQAAABABAAQAAABABAAQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAQADAAACgCIADgDIAAgKIgFAAQgKgBAAAKg");
	this.shape_5.setTransform(212,7.7,1.345,1.345);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#22526A").s().p("AgJAsIAAg+IATAAIAAA+gAgHgbQgDgDAAgEQAAgEADgDQAEgCADAAQAEAAAEACQADADAAAEQAAAEgDADQgEADgEAAQgDAAgEgDg");
	this.shape_6.setTransform(205.5,6,1.345,1.345);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#22526A").s().p("AgJAgIgVg+IAVAAIAJAmIAKgmIAUAAIgUA+g");
	this.shape_7.setTransform(199.2,7.7,1.345,1.345);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#22526A").s().p("AgNAeQgHgEgDgEQgEgGAAgFIATAAQAAAFADACQAEACACAAQADAAADgCQAAAAABgBQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAgBgBAAIgJgDIgMgFIgHgFQgDgEAAgEQAAgJAIgGQAHgGAKABQAMgBAIAGQAIAGAAAJIgUAAQAAgHgIgBQgCABgCABQgCADAAACQAAACADABQABACAGABIAKADQAOAEAAANQAAAHgIAGQgIAGgMAAQgIgBgFgCg");
	this.shape_8.setTransform(186.9,7.7,1.345,1.345);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#22526A").s().p("AgWAbQgGgEAAgJQAAgKAHgFQAJgFANAAIAGAAIAAgDQAAgJgHAAQgHAAAAAHIgTAAQgBgJAJgGQAHgGALABQANAAAGAFQAHAGABAKIAAAbQgBAJADAFIAAABIgTAAIgCgGQgGAGgJABQgJAAgGgGgAgIANQAAABAAAAQAAABAAAAQABABAAAAQAAABAAAAIAFACQADAAACgCQABAAAAgBQABAAAAgBQABAAAAgBQAAAAABAAIAAgKIgGAAQgJgBAAAKg");
	this.shape_9.setTransform(178.6,7.7,1.345,1.345);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#22526A").s().p("AgWAaQgGgGAAgLIAAgoIAUAAIAAAoQAAAIAIAAQAFAAAEgFIAAgrIAUAAIAAA+IgTAAIAAgHQgHAIgJAAQgLAAgFgGg");
	this.shape_10.setTransform(169.9,7.8,1.345,1.345);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#22526A").s().p("AgNAeQgHgDgDgFQgEgFAAgGIATAAQAAAEACADQAEACADAAQADAAADgCQAAAAABgBQAAAAAAgBQABgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAgBgBAAIgJgDIgMgFQgFgCgCgDQgDgEAAgEQAAgJAHgGQAIgGAKABQAMgBAIAGQAIAGAAAJIgUAAQAAgHgIgBQgCABgCABQgBABAAAAQgBABAAAAQAAABAAAAQAAABAAABQAAAAAAABQAAAAAAABQABAAAAABQABAAAAAAIAIADIAJADQAPAEAAANQAAAHgIAGQgHAGgNAAQgIgBgFgCg");
	this.shape_11.setTransform(161.2,7.7,1.345,1.345);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#22526A").s().p("AgWAbQgGgEAAgJQAAgKAIgFQAIgFANAAIAGAAIAAgDQAAgJgHAAQgHAAAAAHIgTAAQAAgJAHgGQAJgGAKABQANAAAGAFQAHAHAAAJIAAAbQAAAJADAFIAAABIgUAAIgBgGQgGAGgJABQgJAAgGgGgAgIANQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQAAABABAAQAAAAABABQAAAAABAAQABAAAAAAQADAAACgCIAEgDIAAgKIgGAAQgJgBAAAKg");
	this.shape_12.setTransform(148.9,7.7,1.345,1.345);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#22526A").s().p("AgSAgIAAg+IASAAIAAAIQAFgJAJAAIAFABIAAASIgHgBQgJAAgDAHIAAAmg");
	this.shape_13.setTransform(142.2,7.7,1.345,1.345);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#22526A").s().p("AgWAbQgGgEAAgJQAAgKAHgFQAJgFANAAIAFAAIAAgDQAAgJgGAAQgHAAAAAHIgUAAQAAgJAIgGQAIgGALABQANAAAGAFQAHAHAAAJIAAAbQAAAJADAFIAAABIgUAAIgCgGQgFAGgJABQgJAAgGgGgAgJANQAAABABAAQAAABAAAAQAAABABAAQAAABABAAQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAQADAAACgCIADgDIAAgKIgFAAQgKgBAAAKg");
	this.shape_14.setTransform(134.6,7.7,1.345,1.345);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#22526A").s().p("AgcAsIAAhWIASAAIABAGQAFgHAJAAQALAAAHAIQAGAJAAAPIAAABQAAAOgGAIQgHAJgLAAQgHAAgHgGIAAAdgAgJgXIAAAYQACAFAHAAQAKAAgBgPIAAgCQABgRgKAAQgGAAgDAFg");
	this.shape_15.setTransform(126,9.3,1.345,1.345);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#22526A").s().p("AgWAbQgGgFAAgIQAAgKAHgFQAJgFANAAIAFAAIAAgDQABgJgHAAQgGAAAAAHIgUAAQAAgIAIgHQAHgGALABQANAAAGAFQAHAGABAKIAAAbQAAAJACAFIAAABIgTAAIgCgGQgGAGgIABQgKAAgGgGgAgIANQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAIAEACQADAAACgCQABAAABgBQAAAAAAgBQABAAAAgBQAAAAAAAAIAAgKIgFAAQgJgBAAAKg");
	this.shape_16.setTransform(113.1,7.7,1.345,1.345);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#22526A").s().p("AgSAgIAAg+IASAAIAAAIQAEgJAKAAIAFABIgBASIgFgBQgKAAgDAHIAAAmg");
	this.shape_17.setTransform(106.4,7.7,1.345,1.345);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#22526A").s().p("AgJAlIgBAHIgSAAIAAhYIAUAAIAAAgQAFgHAHAAQANAAAFAIQAHAJAAAOIAAABQAAAQgHAIQgFAIgNAAQgIAAgFgIgAgIAAIAAAZQACAFAGAAQAHAAACgGIABgMQgBgJgCgDQgDgEgEAAQgGAAgCAEg");
	this.shape_18.setTransform(98.7,6.1,1.345,1.345);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#22526A").s().p("AgUAZQgIgIgBgOIAAgDQAAgKADgGQAEgIAHgEQAHgDAIAAQAOAAAIAJQAIAIAAAOIAAABQAAAPgIAIQgIAJgOAAQgMgBgIgHgAgKgCIAAADQAAAJADAEQACADAFAAQALABAAgRIAAgBQAAgQgLgBQgJAAgBAPg");
	this.shape_19.setTransform(89.5,7.7,1.345,1.345);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#22526A").s().p("AgNAeQgHgEgDgEQgEgGAAgFIATAAQAAAFADACQADACADAAQADAAADgCQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAgBgBAAIgJgDIgMgFQgFgCgCgDQgDgEAAgEQAAgJAHgGQAIgGAKABQAMgBAIAGQAIAGAAAJIgUAAQAAgHgIgBQgCABgCABIgCAFQAAAAAAABQAAAAAAABQABAAAAABQABAAAAAAIAIADIAJADQAPAEAAANQAAAHgIAGQgHAGgNAAQgIgBgFgCg");
	this.shape_20.setTransform(80.9,7.7,1.345,1.345);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#22526A").s().p("AgTAYQgJgIAAgPIAAgBQAAgIADgIQADgHAHgFQAJgDAHAAQANgBAIAJQAHAJAAANIAAAIIglAAQABAFADADQAEACAEAAQAKAAAFgGIAJALQgEAEgGADQgHAEgIAAQgOAAgIgJgAgIgFIASAAIAAgCQABgEgDgDQgDgCgEgBQgIAAgBAMg");
	this.shape_21.setTransform(68.6,7.7,1.345,1.345);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#22526A").s().p("AgWAkQgGgHAAgRQAAgNAGgKQAHgIALAAQAHAAAHAHIAAggIATAAIAABYIgSAAIgBgHQgFAIgJAAQgMAAgGgJgAgIAKIAAAEQAAAQAIAAQAHAAADgGIAAgYQgDgEgHAAQgHAAgBAOg");
	this.shape_22.setTransform(59.5,6.1,1.345,1.345);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#22526A").s().p("AgVAZQgHgIgBgOIAAgDQAAgKADgGQAEgIAHgEQAHgDAIAAQAOAAAIAJQAIAIAAAOIAAABQAAAPgIAIQgIAJgOAAQgNgBgIgHgAgKgCIAAADQAAAIADAFQACADAFAAQALABAAgRIAAgBQAAgQgLgBQgJAAgBAPg");
	this.shape_23.setTransform(46.7,7.7,1.345,1.345);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#22526A").s().p("AgEAjQAFAAAAgFQAAAAgBgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIgGgBIABgHQgJgCgFgGQgIgIAAgPIAAgBQAAgKADgHQAFgHAFgEQAIgEAIAAQALAAAIAHQAHAHAAAMIgSAAQAAgGgCgCQgDgDgEAAQgHAAgBAKIAAAJQgBAJADADQACADAEAAQAEAAADgCQACgCAAgDIASAAQAAAJgIAHQgEAEgGABIgBADQAJACAAAIQAAAHgGAEQgHAEgIAAg");
	this.shape_24.setTransform(38.1,9.5,1.345,1.345);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#22526A").s().p("AgWAbQgGgEAAgJQAAgKAIgFQAHgFANAAIAGAAIAAgDQAAgJgGAAQgHAAAAAHIgUAAQABgJAHgGQAJgGAKABQAMAAAHAFQAHAHAAAJIAAAbQABAKACAEIAAABIgUAAIgCgGQgEAGgKABQgIAAgHgGgAgJANQAAAAABABQAAAAAAABQAAAAABABQAAABAAAAQABABABAAQAAAAABABQAAAAABAAQAAAAABAAQADAAACgCIADgDIAAgKIgFAAQgKgBAAAKg");
	this.shape_25.setTransform(29.7,7.7,1.345,1.345);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#22526A").s().p("AgcAsIAAhWIASAAIABAGQAFgHAJAAQALAAAHAIQAGALAAANIAAABQAAANgHAJQgFAJgMAAQgIAAgGgGIAAAdgAgJgXIAAAYQADAFAGAAQAJAAAAgPIAAgCQAAgRgJAAQgGAAgDAFg");
	this.shape_26.setTransform(21.1,9.3,1.345,1.345);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#22526A").s().p("AgNAeQgHgDgDgFQgEgFAAgGIATAAQAAAEACADQAEACADAAQADAAADgCQAAAAABgBQAAAAAAgBQAAgBABAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAgBgBAAIgJgDIgMgFQgFgCgCgDQgDgEAAgEQAAgJAHgGQAIgGAKABQAMgBAIAGQAIAGAAAJIgUAAQAAgHgIgBQgCABgCABQgBABAAAAQAAABgBAAQAAABAAAAQAAABAAABQAAAAAAABQAAAAAAABQABAAAAABQABAAAAAAIAIADIAJADQAPAEAAANQAAAHgIAGQgHAGgNAAQgIgBgFgCg");
	this.shape_27.setTransform(12.2,7.7,1.345,1.345);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#22526A").s().p("AgUAYQgIgIAAgPIAAgBQAAgJADgHQADgHAIgFQAHgDAIAAQANgBAIAJQAHAJAAANIAAAIIgmAAQACAFADADQADACAFAAQAKAAAFgGIAJALQgEAEgHADQgGAEgIAAQgOAAgJgJgAgJgFIATAAIAAgCQAAgEgCgDQgDgCgEgBQgHAAgDAMg");
	this.shape_28.setTransform(3.9,7.7,1.345,1.345);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,255.2,15.7);


(lib.texto1A = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#22526A").s().p("AAlAgIAAgoQAAgIgEgFQgCgDgJAAQgHAAgGAEQgFAFgBAHIAAAoIgGAAIAAgoQAAgJgDgEQgEgDgIAAQgHAAgEADQgFAEgCAHIAAAqIgHAAIAAg+IAHAAIAAAKQAEgGAEgCQAGgDAGAAQAPAAADANQAEgHAFgCQAHgEAFAAQAVAAAAAXIAAAog");
	this.shape.setTransform(186.7,7.7,1.345,1.345);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#22526A").s().p("AgTAYQgIgJAAgOIAAgBQAAgJAEgHQADgIAHgDQAFgFAIAAQAMAAAJAJQAHAJAAAOIAAABQAAAKgEAGQgCAIgIAEQgGAEgIAAQgMAAgHgJgAgOgSQgGAHAAALIAAABQAAALAGAIQAGAHAIAAQAKAAAFgHQAGgIAAgMIAAAAQAAgIgDgFQgDgGgEgDQgFgEgGAAQgIAAgGAIg");
	this.shape_1.setTransform(175.1,7.8,1.345,1.345);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#22526A").s().p("AgRAYQgIgJAAgOIAAgBQAAgJADgIQAFgHAFgEQAGgEAHAAQAKAAAIAHQAFAFACALIgHAAQAAgHgGgFQgEgFgIAAQgIAAgGAHQgEAHAAAMIAAABQAAANAEAGQAGAHAIAAQAHAAAFgEQAGgFAAgGIAHAAQAAAFgEAGQgEAFgFACQgFADgHAAQgLAAgHgJg");
	this.shape_2.setTransform(166.6,7.8,1.345,1.345);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#22526A").s().p("AgQAbQgHgFAAgIIAHAAQABAHAEACQAEAEAIAAQAHAAAFgDQAEgEAAgEQAAgGgEgDQgFgDgIgCQgGgBgFgCQgFgCgDgDQgBgEAAgEQgBgHAHgGQAGgFAIAAQALAAAGAGQAHAFAAAIIgIAAQAAgFgEgEQgFgEgHAAQgGAAgEADQgDAEAAAEQAAAFACADQAFACAHACQAKADAEABQAFADACADQACADAAAFQAAAIgHAFQgFAFgLAAQgKAAgHgGg");
	this.shape_3.setTransform(154.4,7.8,1.345,1.345);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#22526A").s().p("AgTAcQgFgGAAgHQAAgJAHgGQAIgEANAAIAMAAIAAgHQAAgHgEgEQgFgEgHAAQgGAAgFAEQgFAEAAAFIgHAAQAAgHAHgGQAHgGAJAAQAKAAAHAGQAGAFAAAJIAAAdQAAAKACAEIAAAAIgHAAQgCgCAAgGQgEAEgFADQgGADgFAAQgIAAgHgFgAgLAEQgGAEAAAGQAAAGAEADQAEAEAGAAQAFAAAGgEQAGgEACgFIAAgOIgMAAQgKAAgFAEg");
	this.shape_4.setTransform(146,7.8,1.345,1.345);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#22526A").s().p("AgCAtIAAhYIAFAAIAABYg");
	this.shape_5.setTransform(140.1,6,1.345,1.345);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#22526A").s().p("AgTAcQgFgGAAgHQAAgJAHgGQAJgEAMAAIAMAAIAAgHQAAgHgEgEQgFgEgHAAQgGAAgFAEQgFAEAAAFIgHAAQAAgHAHgGQAHgGAJAAQAKAAAHAGQAGAFAAAJIAAAdQAAAKACAEIAAAAIgHAAIgCgIQgDAEgGADQgGADgFAAQgIAAgHgFgAgLAEQgGAEAAAGQAAAFAEAEQAEAEAGAAQAFAAAGgEQAGgDACgGIAAgOIgMAAQgJAAgGAEg");
	this.shape_6.setTransform(133.9,7.8,1.345,1.345);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#22526A").s().p("AAlAgIAAgoQAAgJgEgEQgDgDgIAAQgHAAgFAEQgGAFAAAHIAAAoIgHAAIAAgoQAAgJgDgEQgDgDgJAAQgHAAgEADQgFAEgCAHIAAAqIgHAAIAAg+IAGAAIABAKQAEgGAEgCQAGgDAHAAQAOAAADANQAEgHAFgCQAHgEAFAAQAVAAAAAXIAAAog");
	this.shape_7.setTransform(122.6,7.7,1.345,1.345);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#22526A").s().p("AgNADIAAgFIAbAAIAAAFg");
	this.shape_8.setTransform(113.2,7,1.345,1.345);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#22526A").s().p("AgSAcQgGgGAAgHQAAgJAIgGQAHgEANAAIANAAIAAgHQgBgHgEgEQgEgEgIAAQgGAAgFAEQgEAEAAAFIgIAAQAAgIAIgFQAGgGAKAAQAKAAAGAGQAGAFAAAJIAAAdQAAAJACAFIAAAAIgHAAQgBgCAAgGQgFAEgFADQgGADgFAAQgJAAgFgFgAgMAEQgFAEAAAGQAAAGAEADQAEAEAGAAQAFAAAHgEQAFgEADgFIAAgOIgNAAQgJAAgHAEg");
	this.shape_9.setTransform(106.5,7.8,1.345,1.345);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#22526A").s().p("AgBAkQgDgEAAgJIAAgpIgLAAIAAgFIALAAIAAgQIAGAAIAAAQIANAAIAAAFIgNAAIAAApQAAAEACAEQADADAEAAIAFgBIAAAGIgHABQgHAAgDgEg");
	this.shape_10.setTransform(99.6,6.8,1.345,1.345);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#22526A").s().p("AgNAgIAAg+IAHAAIAAAKQAFgLALAAIAFABIAAAGIgFAAQgHAAgDADQgFAFgBAGIAAAqg");
	this.shape_11.setTransform(94.6,7.7,1.345,1.345);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#22526A").s().p("AgTAYQgIgJAAgOIAAgBQAAgJADgHQAFgIAFgDQAIgFAGAAQAMAAAIAJQAIAJAAAOIAAABQAAAKgDAGQgDAIgHAEQgHAEgIAAQgLAAgIgJgAgOgSQgGAHAAALIAAABQAAALAGAIQAFAHAJAAQAJAAAHgHQAFgHAAgNIAAAAQAAgIgDgFQgCgGgFgDQgFgEgGAAQgIAAgGAIg");
	this.shape_12.setTransform(86.9,7.8,1.345,1.345);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#22526A").s().p("AgcAqIAAhTIAcAAQANAAAIAHQAIAHAAALQAAAMgIAGQgIAGgNAAIgVAAIAAAigAgVACIAVAAQAKAAAGgEQAFgFAAgJQAAgJgFgFQgFgEgKgBIgWAAg");
	this.shape_13.setTransform(78,6.3,1.345,1.345);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#22526A").s().p("AgDAEIgBgEIABgCQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAAAABQABAAAAABQAAAAABAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAAAgBABIgDABIgDgBg");
	this.shape_14.setTransform(66.8,11.4,1.345,1.345);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#22526A").s().p("AgTAlQgHgGAAgLQAAgHAFgGQAEgGAHgBQgGgEgEgEQgDgEAAgIQgBgKAHgHQAHgFAKAAQALAAAHAGQAHAGAAAKQAAAHgEAFQgEAEgGAEQAHABAFAGQAEAFAAAIQAAALgIAGQgGAHgNgBQgLABgIgHgAgNAHQgGAFAAAIQAAAHAGAGQAFAEAIABQAJgBAGgEQAFgFAAgIQAAgIgFgFQgGgFgJAAQgIAAgFAFgAgLggQgFAFgBAHQABAIAFAFQAEAEAHAAQAIAAAFgEQAFgGAAgHQAAgHgFgFQgFgEgIgBQgHAAgEAFg");
	this.shape_15.setTransform(60.6,6.3,1.345,1.345);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#22526A").s().p("AAIAqIAAhLIgWAJIAAgHIAcgKIABAAIAABTg");
	this.shape_16.setTransform(50.7,6.3,1.345,1.345);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#22526A").s().p("AgSAiQgGgIgBgSIAAgOQAAgRAHgKQAGgKAMABQANgBAHAKQAGAIAAASIAAAOQAAASgGAJQgHAKgMgBQgMAAgHgJgAgNgeQgFAJAAANIAAAPQAAAOAFAJQAFAIAJAAQAIAAAFgIQAFgHAAgPIAAgPQAAgPgFgHQgEgIgKAAQgJABgEAGg");
	this.shape_17.setTransform(42.8,6.3,1.345,1.345);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#22526A").s().p("AgYArIAAgFIAcghQAIgJABgEQADgGAAgEQAAgJgEgEQgFgFgHAAQgJAAgFAGQgFAFAAAJIgHAAQAAgHADgGQAEgGAFgDQAGgEAIAAQAKAAAHAGQAGAGAAALQAAAGgDAHQgDAFgKALIgXAbIArAAIAAAGg");
	this.shape_18.setTransform(34.1,6.2,1.345,1.345);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#22526A").s().p("AgWAsIAAgGIADAAQAFAAAEgCQAEgEACgFIACgJIgYg9IAIAAIATA0IASg0IAHAAIgaBIIgBADQgEAMgMAAg");
	this.shape_19.setTransform(21.8,9.5,1.345,1.345);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#22526A").s().p("AAAAkQgEgEAAgJIAAgpIgLAAIAAgFIALAAIAAgQIAGAAIAAAQIANAAIAAAFIgNAAIAAApQAAAGACACQACADAEAAIAGgBIAAAGIgHABQgHAAgCgEg");
	this.shape_20.setTransform(15.3,6.8,1.345,1.345);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#22526A").s().p("AgCArIAAg+IAGAAIAAA+gAgCgiIgCgDQAAAAAAgBQAAAAABgBQAAAAAAAAQAAgBABAAQAAgBABAAQAAAAAAAAQABgBAAAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAAAABABIABADIgBADQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQgBAAAAgBg");
	this.shape_21.setTransform(11.1,6.2,1.345,1.345);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#22526A").s().p("AgPAnQgIgEgDgKQgFgHAAgNIAAgJQAAgNAFgHQADgJAIgFQAGgEAKAAQANAAAIAHQAIAHABANIgHAAQgCgVgVgBQgLAAgGAJQgIAJAAAPIAAAJQABAOAGAKQAHAIAKABQAMgBAFgFQAGgFABgLIAHAAQgBAMgIAJQgJAGgNAAQgIAAgHgEg");
	this.shape_22.setTransform(4.2,6.3,1.345,1.345);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,192.7,15.4);


(lib.logo2_imagem = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.logo2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,45,29);


(lib.logo1_imagem = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.logo1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,143,44);


(lib.fundo2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.imagem2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,225);


(lib.fundo1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.imagem1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,225);


(lib.fundo_efeito = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A3bRlMAAAgjJMAu3AAAMAAAAjJg");
	this.shape.setTransform(150,112.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,225);


(lib.efeito_vetor = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.botao_texto = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaBIQgOgHgIgKQgHgLAAgOIAaAAQAAANAIAHQAJAHAPAAQANAAAHgGQAHgFAAgJQAAgKgHgGQgHgGgRgFQgSgFgLgGQgVgNAAgVQAAgSAPgMQAPgMAXAAQAQAAAMAGQANAGAGALQAHALAAAMIgaAAQAAgLgHgHQgIgHgNAAQgMAAgHAGQgIAGAAAJQAAAIAIAGQAIAFAQAGQASAFALAGQALAHAEAIQAFAIAAAMQAAATgOALQgPAMgYAAQgQAAgNgGg");
	this.shape.setTransform(71.6,5,0.637,0.637);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgMBLIAAiVIAZAAIAACVg");
	this.shape_1.setTransform(65.4,4.9,0.637,0.637);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAqBLIgNgiIg5AAIgMAiIgcAAIA6iVIAWAAIA5CVgAgVATIArAAIgWg+g");
	this.shape_2.setTransform(58.9,4.9,0.637,0.637);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAzBLIADhyIgsByIgTAAIgshyIADByIgaAAIAAiVIAiAAIAqBzIArhzIAiAAIAACVg");
	this.shape_3.setTransform(48.2,4.9,0.637,0.637);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AApBLIgMgiIg6AAIgMAiIgbAAIA5iVIAXAAIA5CVgAgVATIArAAIgWg+g");
	this.shape_4.setTransform(34.1,4.9,0.637,0.637);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag1BLIAAiVIA0AAQAYAAAOAKQAOAKAAAUQgBAKgFAJQgGAIgLAFQANADAGAIQAHAJAAAOQAAAUgNAMQgNALgbAAgAgbA2IAcAAQAOABAGgHQAHgGAAgKQAAgYgYAAIgfAAgAgbgLIAaAAQAMAAAGgGQAHgEAAgLQAAgMgGgEQgHgFgMAAIgaAAg");
	this.shape_5.setTransform(25.3,4.9,0.637,0.637);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgMBLIAAiVIAZAAIAACVg");
	this.shape_6.setTransform(18.9,4.9,0.637,0.637);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AApBLIgMgiIg6AAIgMAiIgbAAIA5iVIAXAAIA5CVgAgVATIArAAIgWg+g");
	this.shape_7.setTransform(12.3,4.9,0.637,0.637);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgaBIQgOgHgIgKQgHgLAAgOIAaAAQAAANAIAHQAJAHAPAAQANAAAHgGQAHgFAAgJQAAgKgHgGQgHgGgRgFQgSgFgLgGQgVgNAAgVQAAgSAPgMQAPgMAXAAQAQAAAMAGQANAGAGALQAHAKAAANIgaAAQAAgLgHgHQgIgHgNAAQgMAAgHAGQgIAGAAAJQAAAIAIAGQAIAFAQAGQASAFALAGQALAHAFAIQAEAJAAALQAAATgOALQgPAMgYAAQgQAAgNgGg");
	this.shape_8.setTransform(3.6,5,0.637,0.637);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,75.2,9.9);


(lib.botao_base = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#004359").s().p("ArjC5IAAlxIXHAAIAAFxg");
	this.shape.setTransform(74,18.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,148,37);


(lib.base_superiorvetor = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#13445B","#16485F"],[0,1],-6.1,-40.3,-1.8,13.9).s().p("AMvEoQhggRvvjRIy7j7IAAiFMAu3AAAIAADAQhKCvhBBYQhgCDiKAhQgbAHg0ACIgnABQhZAAhpgTg");
	this.shape.setTransform(150,31.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,63);


(lib.base_inferiorvetor = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#D0D8DB","#FFFFFF"],[0,1],0.6,8.5,-3.8,-45.3).s().p("A3bIwIAAtRQAXgjAhgnQBnh7B0gvQAZgMA1gHQBqgQCNAUQBuAPSZCVIRYCMIAAMkg");
	this.shape.setTransform(150,56);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,112);


(lib.texto3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// texto2B
	this.instance = new lib.texto2B("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(94.8,38.5,1,1,0,0,0,94.8,3.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({alpha:1},10,cjs.Ease.get(1)).wait(1));

	// texto2A
	this.instance_1 = new lib.texto2A("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(58.7,81.6,1,1,0,0,0,56.7,10.6);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({y:81.5,alpha:0.002},0).wait(1).to({y:81.1,alpha:0.008},0).wait(1).to({y:80.5,alpha:0.018},0).wait(1).to({y:79.5,alpha:0.035},0).wait(1).to({y:77.9,alpha:0.061},0).wait(1).to({y:75.7,alpha:0.098},0).wait(1).to({y:72.5,alpha:0.152},0).wait(1).to({y:67.6,alpha:0.233},0).wait(1).to({y:60,alpha:0.36},0).wait(1).to({y:49.2,alpha:0.54},0).wait(1).to({y:39.2,alpha:0.707},0).wait(1).to({y:32.7,alpha:0.815},0).wait(1).to({y:28.6,alpha:0.883},0).wait(1).to({y:25.9,alpha:0.929},0).wait(1).to({y:24.1,alpha:0.959},0).wait(1).to({y:22.9,alpha:0.979},0).wait(1).to({y:22.1,alpha:0.991},0).wait(1).to({y:21.7,alpha:0.998},0).wait(1).to({y:21.6,alpha:1},0).wait(11));

	// texto3C
	this.instance_2 = new lib.texto3C("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(25.7,34.9,1,1,0,0,0,24.7,4.9);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({regY:4.8,y:34.7,alpha:0.002},0).wait(1).to({y:34.6,alpha:0.008},0).wait(1).to({y:34.2,alpha:0.018},0).wait(1).to({y:33.7,alpha:0.035},0).wait(1).to({y:33,alpha:0.061},0).wait(1).to({y:31.9,alpha:0.098},0).wait(1).to({y:30.2,alpha:0.152},0).wait(1).to({y:27.8,alpha:0.233},0).wait(1).to({y:24,alpha:0.36},0).wait(1).to({y:18.6,alpha:0.54},0).wait(1).to({y:13.6,alpha:0.707},0).wait(1).to({y:10.4,alpha:0.815},0).wait(1).to({y:8.3,alpha:0.883},0).wait(1).to({y:6.9,alpha:0.929},0).wait(1).to({y:6,alpha:0.959},0).wait(1).to({y:5.4,alpha:0.979},0).wait(1).to({y:5.1,alpha:0.991},0).wait(1).to({y:4.9,alpha:0.998},0).wait(1).to({regY:4.9,alpha:1},0).wait(11));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1,30,114.4,62.2);


(lib.texto2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// texto3B
	this.instance = new lib.texto3B("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(115.6,-7.8,1,1,0,0,0,53.6,7.2);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-7.7,alpha:0.002},0).wait(1).to({y:-7.5,alpha:0.008},0).wait(1).to({y:-7.2,alpha:0.018},0).wait(1).to({y:-6.7,alpha:0.035},0).wait(1).to({y:-5.9,alpha:0.061},0).wait(1).to({y:-4.8,alpha:0.098},0).wait(1).to({y:-3.2,alpha:0.152},0).wait(1).to({y:-0.8,alpha:0.233},0).wait(1).to({y:3,alpha:0.36},0).wait(1).to({y:8.4,alpha:0.54},0).wait(1).to({y:13.4,alpha:0.707},0).wait(1).to({y:16.6,alpha:0.815},0).wait(1).to({y:18.7,alpha:0.883},0).wait(1).to({y:20.1,alpha:0.929},0).wait(1).to({y:21,alpha:0.959},0).wait(1).to({y:21.6,alpha:0.979},0).wait(1).to({y:21.9,alpha:0.991},0).wait(1).to({y:22.1,alpha:0.998},0).wait(1).to({y:22.2,alpha:1},0).wait(1));

	// texto3A
	this.instance_1 = new lib.texto3A("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(84.3,-52.8,1,1,0,0,0,84.3,7.2);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({y:-52.6,alpha:0.002},0).wait(1).to({y:-52.3,alpha:0.008},0).wait(1).to({y:-51.6,alpha:0.018},0).wait(1).to({y:-50.6,alpha:0.035},0).wait(1).to({y:-49.1,alpha:0.061},0).wait(1).to({y:-46.9,alpha:0.098},0).wait(1).to({y:-43.6,alpha:0.152},0).wait(1).to({y:-38.8,alpha:0.233},0).wait(1).to({y:-31.2,alpha:0.36},0).wait(1).to({y:-20.3,alpha:0.54},0).wait(1).to({y:-10.3,alpha:0.707},0).wait(1).to({y:-3.9,alpha:0.815},0).wait(1).to({y:0.3,alpha:0.883},0).wait(1).to({y:3,alpha:0.929},0).wait(1).to({y:4.8,alpha:0.959},0).wait(1).to({y:6,alpha:0.979},0).wait(1).to({y:6.7,alpha:0.991},0).wait(1).to({y:7.1,alpha:0.998},0).wait(1).to({y:7.2,alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-60,169.1,59.4);


(lib.texto1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// texto1B
	this.instance = new lib.texto1B("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(127.6,85.9,1,1,0,0,0,127.6,7.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:85.8},0).wait(1).to({y:85.4},0).wait(1).to({y:84.8},0).wait(1).to({y:83.8},0).wait(1).to({y:82.2},0).wait(1).to({y:80},0).wait(1).to({y:76.8},0).wait(1).to({y:71.9},0).wait(1).to({y:64.3},0).wait(1).to({y:53.5},0).wait(1).to({y:43.5},0).wait(1).to({y:37},0).wait(1).to({y:32.9},0).wait(1).to({y:30.2},0).wait(1).to({y:28.4},0).wait(1).to({y:27.2},0).wait(1).to({y:26.4},0).wait(1).to({y:26},0).wait(1).to({y:25.9},0).wait(50).to({startPosition:0},0).wait(1).to({alpha:0.997},0).wait(1).to({alpha:0.987},0).wait(1).to({alpha:0.969},0).wait(1).to({alpha:0.937},0).wait(1).to({alpha:0.886},0).wait(1).to({alpha:0.803},0).wait(1).to({alpha:0.661},0).wait(1).to({alpha:0.434},0).wait(1).to({alpha:0.244},0).wait(1).to({alpha:0.136},0).wait(1).to({alpha:0.074},0).wait(1).to({alpha:0.036},0).wait(1).to({alpha:0.014},0).wait(1).to({alpha:0.003},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(15));

	// texto1A
	this.instance_1 = new lib.texto1A("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(96.4,37.7,1,1,0,0,0,96.3,7.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({y:37.6},0).wait(1).to({y:37.5},0).wait(1).to({y:37.1},0).wait(1).to({y:36.6},0).wait(1).to({y:35.9},0).wait(1).to({y:34.8},0).wait(1).to({y:33.1},0).wait(1).to({y:30.7},0).wait(1).to({y:26.9},0).wait(1).to({y:21.5},0).wait(1).to({y:16.5},0).wait(1).to({y:13.3},0).wait(1).to({y:11.2},0).wait(1).to({y:9.8},0).wait(1).to({y:8.9},0).wait(1).to({y:8.3},0).wait(1).to({y:8},0).wait(1).to({y:7.8},0).wait(1).to({y:7.7},0).wait(52).to({startPosition:0},0).wait(1).to({alpha:0.997},0).wait(1).to({alpha:0.987},0).wait(1).to({alpha:0.969},0).wait(1).to({alpha:0.937},0).wait(1).to({alpha:0.886},0).wait(1).to({alpha:0.803},0).wait(1).to({alpha:0.661},0).wait(1).to({alpha:0.434},0).wait(1).to({alpha:0.244},0).wait(1).to({alpha:0.136},0).wait(1).to({alpha:0.074},0).wait(1).to({alpha:0.036},0).wait(1).to({alpha:0.014},0).wait(1).to({alpha:0.003},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,30,255.2,63.7);


(lib.logo2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.logo2_imagem("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(22.5,14.5,1,1,0,0,0,22.5,14.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.002},0).wait(1).to({alpha:0.008},0).wait(1).to({alpha:0.018},0).wait(1).to({alpha:0.035},0).wait(1).to({alpha:0.061},0).wait(1).to({alpha:0.098},0).wait(1).to({alpha:0.152},0).wait(1).to({alpha:0.233},0).wait(1).to({alpha:0.36},0).wait(1).to({alpha:0.54},0).wait(1).to({alpha:0.707},0).wait(1).to({alpha:0.815},0).wait(1).to({alpha:0.883},0).wait(1).to({alpha:0.929},0).wait(1).to({alpha:0.959},0).wait(1).to({alpha:0.979},0).wait(1).to({alpha:0.991},0).wait(1).to({alpha:0.998},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,45,29);


(lib.logo1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.logo1_imagem("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(71.5,22,1,1,0,0,0,71.5,22);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.002},0).wait(1).to({alpha:0.008},0).wait(1).to({alpha:0.018},0).wait(1).to({alpha:0.035},0).wait(1).to({alpha:0.061},0).wait(1).to({alpha:0.098},0).wait(1).to({alpha:0.152},0).wait(1).to({alpha:0.233},0).wait(1).to({alpha:0.36},0).wait(1).to({alpha:0.54},0).wait(1).to({alpha:0.707},0).wait(1).to({alpha:0.815},0).wait(1).to({alpha:0.883},0).wait(1).to({alpha:0.929},0).wait(1).to({alpha:0.959},0).wait(1).to({alpha:0.979},0).wait(1).to({alpha:0.991},0).wait(1).to({alpha:0.998},0).wait(1).to({alpha:1},0).wait(50).to({startPosition:0},0).wait(1).to({alpha:0.993},0).wait(1).to({alpha:0.969},0).wait(1).to({alpha:0.915},0).wait(1).to({alpha:0.803},0).wait(1).to({alpha:0.555},0).wait(1).to({alpha:0.244},0).wait(1).to({alpha:0.101},0).wait(1).to({alpha:0.036},0).wait(1).to({alpha:0.008},0).wait(1).to({alpha:0},0).to({_off:true},1).wait(20));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,143,44);


(lib.fundo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	mask.setTransform(150,125);

	// efeito
	this.instance = new lib.fundo_efeito("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(150,-95,1,0.844,0,0,0,150,112.5);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({_off:false},0).wait(1).to({scaleY:0.85,y:-94.6,alpha:0.998},0).wait(1).to({scaleY:0.85,y:-93.4,alpha:0.992},0).wait(1).to({scaleY:0.85,y:-91.2,alpha:0.982},0).wait(1).to({scaleY:0.85,y:-87.6,alpha:0.965},0).wait(1).to({scaleY:0.85,y:-82.3,alpha:0.939},0).wait(1).to({scaleY:0.86,y:-74.6,alpha:0.902},0).wait(1).to({scaleY:0.87,y:-63.4,alpha:0.848},0).wait(1).to({scaleY:0.88,y:-46.5,alpha:0.767},0).wait(1).to({scaleY:0.9,y:-20.3,alpha:0.64},0).wait(1).to({scaleY:0.93,y:17.2,alpha:0.46},0).wait(1).to({scaleY:0.95,y:51.7,alpha:0.293},0).wait(1).to({scaleY:0.97,y:74.1,alpha:0.185},0).wait(1).to({scaleY:0.98,y:88.4,alpha:0.117},0).wait(1).to({scaleY:0.99,y:97.8,alpha:0.071},0).wait(1).to({scaleY:0.99,y:104.1,alpha:0.041},0).wait(1).to({scaleY:1,y:108.2,alpha:0.021},0).wait(1).to({scaleY:1,y:110.8,alpha:0.009},0).wait(1).to({scaleY:1,y:112.1,alpha:0.002},0).wait(1).to({y:112.5,alpha:0},0).to({_off:true},1).wait(1));

	// fundo2
	this.instance_1 = new lib.fundo2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,-95,1,0.844,0,0,0,150,112.5);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(79).to({_off:false},0).wait(1).to({scaleY:0.85,y:-94.6},0).wait(1).to({scaleY:0.85,y:-93.4},0).wait(1).to({scaleY:0.85,y:-91.2},0).wait(1).to({scaleY:0.85,y:-87.6},0).wait(1).to({scaleY:0.85,y:-82.3},0).wait(1).to({scaleY:0.86,y:-74.6},0).wait(1).to({scaleY:0.87,y:-63.4},0).wait(1).to({scaleY:0.88,y:-46.5},0).wait(1).to({scaleY:0.9,y:-20.3},0).wait(1).to({scaleY:0.93,y:17.2},0).wait(1).to({scaleY:0.95,y:51.7},0).wait(1).to({scaleY:0.97,y:74.1},0).wait(1).to({scaleY:0.98,y:88.4},0).wait(1).to({scaleY:0.99,y:97.8},0).wait(1).to({scaleY:0.99,y:104.1},0).wait(1).to({scaleY:1,y:108.2},0).wait(1).to({scaleY:1,y:110.8},0).wait(1).to({scaleY:1,y:112.1},0).wait(1).to({y:112.5},0).wait(2));

	// efeito
	this.instance_2 = new lib.fundo_efeito("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(150,112.5,1,1,0,0,0,150,112.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(79).to({_off:false},0).wait(1).to({y:112.8,alpha:0.002},0).wait(1).to({scaleY:1,y:114.1,alpha:0.008},0).wait(1).to({scaleY:1,y:116.3,alpha:0.018},0).wait(1).to({scaleY:0.99,y:119.9,alpha:0.035},0).wait(1).to({scaleY:0.99,y:125.2,alpha:0.061},0).wait(1).to({scaleY:0.99,y:132.9,alpha:0.098},0).wait(1).to({scaleY:0.98,y:144.1,alpha:0.152},0).wait(1).to({scaleY:0.96,y:160.9,alpha:0.233},0).wait(1).to({scaleY:0.94,y:187.1,alpha:0.36},0).wait(1).to({scaleY:0.92,y:224.7,alpha:0.54},0).wait(1).to({scaleY:0.89,y:259.2,alpha:0.707},0).wait(1).to({scaleY:0.87,y:281.6,alpha:0.815},0).wait(1).to({scaleY:0.86,y:295.9,alpha:0.883},0).wait(1).to({scaleY:0.86,y:305.3,alpha:0.929},0).wait(1).to({scaleY:0.85,y:311.6,alpha:0.959},0).wait(1).to({scaleY:0.85,y:315.7,alpha:0.979},0).wait(1).to({scaleY:0.85,y:318.3,alpha:0.991},0).wait(1).to({scaleY:0.85,y:319.6,alpha:0.998},0).wait(1).to({regY:112.6,y:320.1,alpha:1},0).to({_off:true},1).wait(1));

	// fundo1
	this.instance_3 = new lib.fundo1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(150.1,112.6,1.12,1.12,0,0,0,150,112.5);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({startPosition:0},0).wait(1).to({scaleX:1.12,scaleY:1.12},0).wait(1).to({scaleX:1.12,scaleY:1.12},0).wait(1).to({scaleX:1.12,scaleY:1.12},0).wait(1).to({scaleX:1.11,scaleY:1.11},0).wait(1).to({scaleX:1.11,scaleY:1.11},0).wait(1).to({scaleX:1.1,scaleY:1.1},0).wait(1).to({scaleX:1.09,scaleY:1.09},0).wait(1).to({scaleX:1.08,scaleY:1.08},0).wait(1).to({scaleX:1.06,scaleY:1.06,x:150},0).wait(1).to({scaleX:1.03,scaleY:1.03,x:150.1},0).wait(1).to({scaleX:1.02,scaleY:1.02},0).wait(1).to({scaleX:1.01,scaleY:1.01,y:112.5},0).wait(1).to({scaleX:1.01,scaleY:1.01},0).wait(1).to({scaleX:1,scaleY:1},0).wait(1).to({scaleX:1,scaleY:1,y:112.6},0).wait(1).to({scaleX:1,scaleY:1,x:150,y:112.5},0).wait(1).to({scaleX:1,scaleY:1,x:150.1,y:112.6},0).wait(1).to({x:150,y:112.5},0).wait(60).to({startPosition:0},0).wait(1).to({y:112.8},0).wait(1).to({scaleY:1,y:114.1},0).wait(1).to({scaleY:1,y:116.3},0).wait(1).to({scaleY:0.99,y:119.9},0).wait(1).to({scaleY:0.99,y:125.2},0).wait(1).to({scaleY:0.99,y:132.9},0).wait(1).to({scaleY:0.98,y:144.1},0).wait(1).to({scaleY:0.96,y:160.9},0).wait(1).to({scaleY:0.94,y:187.1},0).wait(1).to({scaleY:0.92,y:224.7},0).wait(1).to({scaleY:0.89,y:259.2},0).wait(1).to({scaleY:0.87,y:281.6},0).wait(1).to({scaleY:0.86,y:295.9},0).wait(1).to({scaleY:0.86,y:305.3},0).wait(1).to({scaleY:0.85,y:311.6},0).wait(1).to({scaleY:0.85,y:315.7},0).wait(1).to({scaleY:0.85,y:318.3},0).wait(1).to({scaleY:0.85,y:319.6},0).wait(1).to({regY:112.6,y:320.1},0).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,238.6);


(lib.efeito = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// efeito
	this.instance = new lib.efeito_vetor("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.998},0).wait(1).to({alpha:0.992},0).wait(1).to({alpha:0.982},0).wait(1).to({alpha:0.965},0).wait(1).to({alpha:0.939},0).wait(1).to({alpha:0.902},0).wait(1).to({alpha:0.848},0).wait(1).to({alpha:0.767},0).wait(1).to({alpha:0.64},0).wait(1).to({alpha:0.46},0).wait(1).to({alpha:0.293},0).wait(1).to({alpha:0.185},0).wait(1).to({alpha:0.117},0).wait(1).to({alpha:0.071},0).wait(1).to({alpha:0.041},0).wait(1).to({alpha:0.021},0).wait(1).to({alpha:0.009},0).wait(1).to({alpha:0.002},0).wait(1).to({alpha:0},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.botao = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// botao_texto
	this.instance = new lib.botao_texto("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(73.6,18,1,1,0,0,0,37.6,5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).wait(1).to({alpha:0.007},0).wait(1).to({alpha:0.031},0).wait(1).to({alpha:0.085},0).wait(1).to({alpha:0.197},0).wait(1).to({alpha:0.445},0).wait(1).to({alpha:0.756},0).wait(1).to({alpha:0.899},0).wait(1).to({alpha:0.964},0).wait(1).to({alpha:0.992},0).wait(1).to({alpha:1},0).wait(1));

	// botao_base
	this.instance_1 = new lib.botao_base("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(74,18.6,0.024,0.054,0,0,0,74,18.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({scaleX:0.08},0).wait(1).to({scaleX:0.46},0).wait(1).to({scaleX:0.94},0).wait(1).to({scaleX:1},0).wait(1).to({scaleY:0.06,y:18.5},0).wait(1).to({scaleY:0.07},0).wait(1).to({scaleY:0.08},0).wait(1).to({scaleY:0.11},0).wait(1).to({scaleY:0.16,y:18.6},0).wait(1).to({scaleY:0.24},0).wait(1).to({scaleY:0.38,y:18.5},0).wait(1).to({scaleY:0.59},0).wait(1).to({scaleY:0.77},0).wait(1).to({scaleY:0.87},0).wait(1).to({scaleY:0.93},0).wait(1).to({scaleY:0.97},0).wait(1).to({scaleY:0.99},0).wait(1).to({scaleY:1},0).wait(1).to({scaleY:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(72.3,17.6,3.5,2);


(lib.base_superiior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3bGQIAAsfMAu3AAAIAAMfg");
	mask.setTransform(150,40);

	// vetor
	this.instance = new lib.base_superiorvetor("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(150,-33.5,1,1,0,0,0,150,31.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({y:-33.3},0).wait(1).to({y:-33},0).wait(1).to({y:-32.3},0).wait(1).to({y:-31.1},0).wait(1).to({y:-29.5},0).wait(1).to({y:-27.1},0).wait(1).to({y:-23.6},0).wait(1).to({y:-18.3},0).wait(1).to({y:-10.1},0).wait(1).to({y:1.7},0).wait(1).to({y:12.5},0).wait(1).to({y:19.5},0).wait(1).to({y:24},0).wait(1).to({y:26.9},0).wait(1).to({y:28.9},0).wait(1).to({y:30.2},0).wait(1).to({y:31},0).wait(1).to({y:31.4},0).wait(1).to({y:31.5},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.base_inferior = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mascara (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3bJTIAAylMAu3AAAIAASlg");
	mask.setTransform(150,53.5);

	// base
	this.instance = new lib.base_inferiorvetor("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(150,111,1,1,0,0,0,150,56);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({startPosition:0},0).wait(1).to({y:110.9},0).wait(1).to({y:110.7},0).wait(1).to({y:110.4},0).wait(1).to({y:109.9},0).wait(1).to({y:109.2},0).wait(1).to({y:108.3},0).wait(1).to({y:106.8},0).wait(1).to({y:104.5},0).wait(1).to({y:101.3},0).wait(1).to({y:98.3},0).wait(1).to({y:96.3},0).wait(1).to({y:95.1},0).wait(1).to({y:94.3},0).wait(1).to({y:93.7},0).wait(1).to({y:93.4},0).wait(1).to({y:93.2},0).wait(1).to({y:93},0).wait(1).to({startPosition:0},0).wait(60).to({startPosition:0},0).wait(1).to({y:92.9},0).wait(1).to({y:92.7},0).wait(1).to({y:92.4},0).wait(1).to({y:91.8},0).wait(1).to({y:91},0).wait(1).to({y:89.8},0).wait(1).to({y:88.2},0).wait(1).to({y:85.7},0).wait(1).to({y:82.1},0).wait(1).to({y:76.5},0).wait(1).to({y:70},0).wait(1).to({y:65},0).wait(1).to({y:61.8},0).wait(1).to({y:59.7},0).wait(1).to({y:58.3},0).wait(1).to({y:57.3},0).wait(1).to({y:56.7},0).wait(1).to({y:56.3},0).wait(1).to({y:56.1},0).wait(1).to({y:56},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,55,300,58);


(lib.geral = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_119 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(119).call(this.frame_119).wait(1));

	// borda
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#22526A").ss(1,1,1).p("A3bzhMAu3AAAMAAAAnDMgu3AAAg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(120));

	// efeito
	this.instance = new lib.efeito("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},19).wait(101));

	// botao
	this.instance_1 = new lib.botao("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(99,219.5,1,1,0,0,0,74,18.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(99).to({_off:false},0).wait(21));

	// texto3
	this.instance_2 = new lib.texto3("synched",0,false);
	this.instance_2.parent = this;
	this.instance_2.setTransform(119.8,171,1,1,0,0,0,94.8,21);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(84).to({_off:false},0).wait(36));

	// texto2
	this.instance_3 = new lib.texto2("synched",0,false);
	this.instance_3.parent = this;
	this.instance_3.setTransform(190.5,26.7,1,1,0,0,0,84.5,14.7);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(84).to({_off:false},0).wait(36));

	// texto1
	this.instance_4 = new lib.texto1("synched",0,false);
	this.instance_4.parent = this;
	this.instance_4.setTransform(146.5,219.9,1,1,0,0,0,127.6,16.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},99).wait(21));

	// logo2
	this.instance_5 = new lib.logo2_1("synched",0,false);
	this.instance_5.parent = this;
	this.instance_5.setTransform(258.5,219.5,1,1,0,0,0,22.5,14.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(84).to({_off:false},0).wait(36));

	// logo1
	this.instance_6 = new lib.logo1_1("synched",0,false);
	this.instance_6.parent = this;
	this.instance_6.setTransform(211.5,35,1,1,0,0,0,71.5,22);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true},99).wait(21));

	// base_superiior
	this.instance_7 = new lib.base_superiior("synched",0,false);
	this.instance_7.parent = this;
	this.instance_7.setTransform(150,31.5,1,1,0,0,0,150,31.5);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(79).to({_off:false},0).wait(41));

	// base_inferior
	this.instance_8 = new lib.base_inferior("synched",0,false);
	this.instance_8.parent = this;
	this.instance_8.setTransform(150,194,1,1,0,0,0,150,56);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(120));

	// fundo
	this.instance_9 = new lib.fundo("synched",0,false);
	this.instance_9.parent = this;
	this.instance_9.setTransform(150,112.5,1,1,0,0,0,150,112.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(120));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,302,297.7);


// stage content:
(lib.IcarrosWebmotors_Arroba_300x250_conforto_v1 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// geral
	this.instance = new lib.geral();
	this.instance.parent = this;
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(132.1,111.6,336,318.5);
// library properties:
lib.properties = {
	width: 300,
	height: 250,
	fps: 24,
	color: "#333333",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"imagem1.jpg", id:"imagem1"},
		{src:"imagem2.jpg", id:"imagem2"},
		{src:"logo1.png", id:"logo1"},
		{src:"logo2.png", id:"logo2"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;